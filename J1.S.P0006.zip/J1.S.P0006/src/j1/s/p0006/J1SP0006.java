/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0006;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author lehun
 */
public class J1SP0006 {

    static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        display();

    }

    //display main
    static void display() {
        J1SP0006 searcher = new J1SP0006();
        int size = inputint("enter size of array: ");
        int search = inputint("Enter search value:");
        int[] array = randomarray(size);
//        int[] array = {-1, 5, 6, 18, 19, 25, 46, 78, 102, 114};
        Arrays.sort(array);
        searcher.displayArray(array);
        displayBinearySearch(array, search);
//        System.out.print("]");
    }

    static void displayBinearySearch(int[] array, int search) {
        int last = array.length - 1;
        J1SP0006 searcher = new J1SP0006();
        int foundIndex = Notshowing(array, 0, last, search);
        if (foundIndex == -1) {
            System.out.println("can't Found " + search + " in array");
        } else {
            System.out.println("Found " + search + " at index: " + foundIndex);
        }
        System.out.println("Do you want to show althorigim??");
        if (!checkYN()) {
            return;
        } else {
            searcher.binarySearch(array, 0, last, search, 1);
        }

    }

    private static boolean checkYN() {
        while (true) {
            String result = in.nextLine();
            if (result.length() == 1) {
                char resultChar = result.charAt(0);
                if (resultChar == 'y' || resultChar == 'Y') {
                    return true;
                }
                if (resultChar == 'n' || resultChar == 'N') {
                    return false;
                }
            }
            System.err.println("Re-input");
        }
    }

    public int binarySearch(int[] array, int start, int end, int searchVal, int step) {
        int middleI = findMedianIndex(array, start, end);
        //if not middle not exist => not found search value
        if (middleI == -1) {
            System.err.printf("Step " + step + " (searched value is absent)\n");
            return -1;
        }
        //if found search val
        if (searchVal == array[middleI]) {
            System.out.print("Step " + step + " (middle element is "
                    + array[middleI] + " == " + searchVal + "): ");
            displayPartOfArray(array, start, end);
            return middleI;
        } //if middle > search value, searching the left part side of middle
        else if (array[middleI] > searchVal) {
            System.out.print("Step " + step + " (middle element is "
                    + array[middleI] + " > " + searchVal + "): ");
            displayPartOfArray(array, start, end);
//            System.out.println("Index of middle: "+middleI);
            return binarySearch(array, start, middleI - 1, searchVal, ++step);
        } else if (array[middleI] < searchVal) {
            System.out.print("Step " + step + " (middle element is "
                    + array[middleI] + " < " + searchVal + "): ");
            displayPartOfArray(array, start, end);
//            System.out.println("Index of middle: "+middleI);
            return binarySearch(array, middleI + 1, end, searchVal, ++step);
        }
        return -1;
    }

    public static int Notshowing(int[] array, int start, int end, int searchVal) {
        int middleI = findMedianIndex(array, start, end);
        if (middleI == -1) {
            return -1;
        }
        if (searchVal == array[middleI]) {
            return middleI;
        } else if (array[middleI] > searchVal) {
            return Notshowing(array, start, middleI - 1, searchVal);
        } else if (array[middleI] < searchVal) {
            return Notshowing(array, middleI + 1, end, searchVal);
        }
        return -1;
    }
// create random array

    static int[] randomarray(int length) {
        int[] array = new int[length];
        //loop from 0-to size of user input to create random number
        for (int i = 0; i < length; i++) {
            array[i] = new Random().nextInt(length);
        }
        return array;
    }
// check input int size and search number

    static int inputint(String p1) {
        while (true) {
            try {
                System.out.println(p1);
                int size = Integer.parseInt(in.nextLine());
                if (size < 0) {
                    System.err.println("Please enter positive number:");

                } else {
                    return size;
                }
            } catch (Exception e) {
                System.err.println("Please enter number with out character!!");
            }
        }
    }

    public void displayArray(int[] arr) {
        System.out.print("The sorted array: ");
        System.out.print("[");
        // loop take value from 0 to end of array to take value 
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i < arr.length - 1) {
                System.out.print(", ");
            }

        }
        System.out.print("]");
        System.out.println("");
    }

    public static void displayPartOfArray(int[] arr, int begin, int last) {

        // loop take value from 0 to end of array to take value 
        for (int i = begin; i <= last; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("");
    }

    static int findMedianIndex(int array[], int begin, int end) {
        if (begin > end) {
            return -1;
        }
        return (int) ((begin + end) / 2);
    }

}
